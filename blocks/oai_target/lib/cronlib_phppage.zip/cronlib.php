<?php

require_once 'XML/Serializer.php';


include_once realpath(dirname(__FILE__) . DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . "common.php";
include_once LIB_DIR . "Course.php";

class cronlib {

    function __construct($course_id, $verb) {
		
        if ($verb == "GetSql") {
            header("Content-type: text/html");
            echo do_verb_sql();

        }

    }

}

function do_verb_sql() {
    global $CFG, $DB;
	
    $d = DIRECTORY_SEPARATOR;
    $base = $CFG->dirroot.$d.'lom'.$d;
	
    $output = "<html><body>";
    
    $lom_files = array();

    $dirIter = new RecursiveDirectoryIterator($base, RecursiveDirectoryIterator::KEY_AS_PATHNAME);
    $recIter = new RecursiveIteratorIterator($dirIter, RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($recIter as $info) {
        if (($info->isFile()) && fnmatch("*json", $info->getFilename())) {
            $lom_files[$info->getFilename()] = $info->getPathname();
        }
    }
	
    $output .= "<ul>";
    foreach ($lom_files as $lom => $lompath) {
        $output .= "<li>$lom<ul><li>$lompath</li><pre>";
        $output .= json_to_xml(file_get_contents($lompath));

//-- create SQL command html output for debug
//-- use function json_to_xml() (allready exist) to parse json and create xml
		$output .= "SQL COMMAND-> INSERT INTO agrimoodle.oai_records SET serial= 'foo', provider='foo', url='foo', enterdate='foo', oai_identifier='foo', oai_set='foo', datestamp='null', deleted='',lom_record='".json_to_xml(file_get_contents($lompath))."';";
        $output .= "</pre></ul></li>";

//-- send SQL command to mysql to execute
//-- use function json_to_xml() (allready exist) to parse json and create xml

		$record = new stdClass;
		$record->provider 		= 'foo';
		$record->url			= 'foo';
		$record->enterdate		= '0000-00-00 00:00:00';
		$record->oai_identifier	= 'foo';
		$record->oai_set		= 'foo';
		$record->datestamp		= '0000-00-00 00:00:00';
		$record->deleted		= 'false';
		$record->lom_record		= ''.json_to_xml(file_get_contents($lompath)).'';
		$DB->insert_record('oai_records', $record, false);
		   
   $output .= "</ul></body></html>";
   }
   return $output;
}

function json_to_xml($json) {

// -- this maybe not be used if XML_Serializer() workd for u.
	$data = json_decode($json, true);	
	$json = $data;

	$xml_json = new SimpleXMLElement("<json></json>");
//-- use array_to_xml function (new function) to get xml. 
	array_to_xml($json,$xml_json);
	$xmlstring = $xml_json->asXML();
//-- my function return some unacceptable tag name <0> so use str_replace() to replace them with item0  
	$xmlstring1rstRplc = str_replace("<0>", "<item0>", $xmlstring);
	$xmlstring2ndRplc = str_replace("</0>", "</item0>", $xmlstring1rstRplc);
	return $xmlstring2ndRplc;
}

function array_to_xml($json, $xml_json) {
	foreach($json as $key => $keyvalue) {
		if(is_array($keyvalue)) {
			if(!is_numeric($key)){
				$subnode = $xml_json->addChild("$key");
				array_to_xml($keyvalue, $subnode);
			}
			else{
				array_to_xml($keyvalue, $xml_json);
			}
		}
		else {
			$xml_json->addChild("$key","$keyvalue");
		}
	}
}

$verb = $_GET['verb'];

//$course_id = intval($_GET['id']);
// if course id not valid exit

if (empty($verb)) {
    print_r("Invalid verb!");
    exit;
}

new cronlib(10, $verb);
?>
